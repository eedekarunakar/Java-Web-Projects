package studentportal;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class  Course_OfferedView_Main extends HttpServlet
{
		public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
		{
			System.out.println("In Course_OfferedView_Main Servlet");
			RequestDispatcher rd=req.getRequestDispatcher("./Course_OfferedView_Main.jsp");
			rd.forward(req,res);
		}
}
