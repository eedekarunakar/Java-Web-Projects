package studentportal;

import java.sql.*;
public class  MySQLDriver
{
	static Connection con=null;
	public static Connection getConnection() throws Exception
	{		
				
				if(con==null)
				{
						Class.forName("com.mysql.jdbc.Driver");		
						String url = "jdbc:mysql://localhost:3306/test";
						con = DriverManager.getConnection(url,"root","root");				
				}
				else
				{
					if(con.isClosed())
					{
						Class.forName("com.mysql.jdbc.Driver");		
						String url = "jdbc:mysql://localhost:3306/test";
						con = DriverManager.getConnection(url,"root","root");					
					}
				}
				return con;
	}
}