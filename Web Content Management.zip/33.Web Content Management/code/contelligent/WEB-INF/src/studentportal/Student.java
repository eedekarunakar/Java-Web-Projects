package studentportal;
import java.io.*;
import java.sql.*;

public class Student implements Serializable
{
		public String sid,sname,sadd,semail,slname,slstatus;
		public Date sdob,sdoa;
		public int sphone;
		public Student(String sid,String sname,String sadd,Date sdob,int sphone,String semail,Date sdoa,String slname,String slstatus)
		{
			this.sid=sid;
			this.sname=sname;
			this.sadd=sadd;
			this.sdob=sdob;
			this.sphone=sphone;
			this.semail=semail;
			this.sdoa=sdoa;
			this.slname=slname;
			this.slstatus=slstatus;
		}
};
