// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 1/28/2008 10:09:48 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   FacultyRegRemote.java

package studentportalBeans;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;

// Referenced classes of package studentportalBeans:
//            Faculty

public interface FacultyRegRemote
    extends EJBObject
{

    public abstract boolean insertFacultyRec(String s, String s1, String s2, String s3, int i, String s4, String s5, 
            String s6, String s7, String s8, String s9)
        throws RemoteException;

    public abstract boolean updateFacultyRec(String s, String s1, String s2, String s3, int i, String s4, String s5, 
            String s6, String s7, String s8)
        throws RemoteException;

    public abstract boolean removeFacultyRec(String s)
        throws RemoteException;

    public abstract Faculty searchByEmail(String s)
        throws RemoteException;

    public abstract String getMessage()
        throws RemoteException;
}