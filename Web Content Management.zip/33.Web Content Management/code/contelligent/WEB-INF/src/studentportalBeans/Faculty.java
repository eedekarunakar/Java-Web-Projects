// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 1/28/2008 10:09:42 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Faculty.java

package studentportalBeans;

import java.io.Serializable;
import java.sql.Date;

public class Faculty
    implements Serializable
{

    public Faculty(String s, String s1, String s2, Date date, int i, String s3, Date date1, 
            String s4, String s5, String s6, String s7)
    {
        fid = s;
        fname = s1;
        fadd = s2;
        fdob = date;
        fphone = i;
        femail = s3;
        fdoa = date1;
        fdept = s4;
        fdeg = s5;
        flname = s6;
        flstatus = s7;
    }

    public String fid;
    public String fname;
    public String fadd;
    public String femail;
    public String flname;
    public String flstatus;
    public String fdept;
    public String fdeg;
    public Date fdob;
    public Date fdoa;
    public int fphone;
}