package studentportal;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class NotificationServlet extends HttpServlet
{
	ServletConfig sc;
	public void init(ServletConfig sc)throws ServletException
	{
		super.init(sc);
		this.sc=sc;
	}
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		String nid=req.getParameter("nid");
		String advdate=req.getParameter("advdate");
		String advldate=req.getParameter("advldate");
		String note=req.getParameter("Note");
		String whome="STU";

		String status="C";
		String action=req.getParameter("action");

		res.setContentType("text/html");

		PrintWriter out=res.getWriter();

		try{
		Connection con=MySQLDriver.getConnection();
		con.setAutoCommit(false);
		Statement st=con.createStatement();
		if(action.equals("Send"))
		{
			String qry="insert into notification_master values('"+nid+"','"+advdate+"','"+advldate+"','"+note+"','"+whome+"','"+status+"')";
			System.out.println(qry);
			int i=st.executeUpdate(qry);
			if(i==1)
			{
				
				   HttpSession hs=req.getSession();
				   String qry1="insert into ADMIN_CORPORATE values('"+(String)hs.getAttribute("CorId")+"','"+nid+"','"+advdate+"','"+advldate+"','"+note+"')";
				   System.out.println(qry1);
				   int j=st.executeUpdate(qry1);
				   if(j==1)
					   con.commit();
				   else
					   con.rollback();
				   RequestDispatcher rd=req.getRequestDispatcher("/NotificationInsertSuc.jsp");
					rd.forward(req,res);
			}
			else 
			{
					RequestDispatcher rd=req.getRequestDispatcher("/Notificaitons.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Insertion Operation Faild<br>* Try Once Again</font></p>");
					return;
			}
		}
		}//try
		catch(Exception e)
		{
			e.printStackTrace();
			RequestDispatcher rd=req.getRequestDispatcher("/Notificaitons.jsp");
			rd.include(req,res);
			out.println("<p><font color=\"#FF0000\">*Operation Faild<br>* Try Once Again</font></p>");
			return;
		}
	}
	public void destroy()
	{
	}
}
