package studentportal;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import javax.naming.*;
import java.util.*;
import java.sql.*;
public class  StudentMasterServlet extends HttpServlet
{
		
		public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
		{
			System.out.println("In StudentRegServlet Servlet");
			try
			{
			String sid=req.getParameter("sid");
			String sname=req.getParameter("sname");
			String sadd=req.getParameter("sadd");
			String sdob=req.getParameter("sdob");
			int sphone =Integer.parseInt(req.getParameter("sphone"));
			
			String semail=req.getParameter("semail");
			String cid=req.getParameter("cid");
			String sdoa=req.getParameter("sdoa");
			String slogin=req.getParameter("slogin");
			String slstatus="No";
			String action=req.getParameter("action");
			System.out.println("sid"+sid);
			System.out.println("sdoa"+sdoa);
			System.out.println("action"+action);
			System.out.println("cid"+cid);
			
				    		
							if(action.equals("Submit"))
							{
									java.sql.Connection con=MySQLDriver.getConnection();
									java.sql.PreparedStatement ps=con.prepareStatement("insert into student_master(student_name, student_address, student_dob, student_phone, student_email, student_admt_date, student_login_name, student_login_status, course_id) values(?,?,?,?,?,?,?,?,?)");
									ps.setString(1,sname);
									ps.setString(2,sadd);
									ps.setString(3,sdob);
									ps.setInt(4,sphone);
									ps.setString(5,semail);
									ps.setString(6,sdoa);
									ps.setString(7,slogin);
									ps.setString(8,slstatus);
									ps.setString(9,cid);
									int c=ps.executeUpdate();
									if(c>0)
									{
										RequestDispatcher rd=req.getRequestDispatcher("/Sucess.jsp?ope=Insert");
										rd.include(req,res);
										return;
									}
									else
									{
										System.out.println("Inddd");
										RequestDispatcher rd=req.getRequestDispatcher("/StudentRegForm.jsp");
										rd.include(req,res);
										
										return;
										}
							}// submit if
							
			}
			catch(Exception e)
			{
				e.printStackTrace();
				RequestDispatcher rd=req.getRequestDispatcher("/StudentRegForm.jsp");
				rd.include(req,res);
				
				return;
			}
		}
}
