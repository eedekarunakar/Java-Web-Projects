/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dbconn;
import java.sql.*;

public class databasecon 
{
	static Connection conn;
	public static Connection getconnection()
	{
 		 			
		try
		{
			Class.forName("com.mysql.jdbc.Driver");	
			//conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hallticketdb","root","mysql");
                        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hallticketdb","root","root");
			System.out.println("Database Connected...");
                 }
		catch(Exception e)
		{
			System.out.println("Database Failed"+e);
		}
		return conn;
                
	}
	
}
