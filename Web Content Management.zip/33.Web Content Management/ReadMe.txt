1)install java
2)install tomcat
3)install mysql(provide username:"root" and password:"root")
4)install mysql front
5)run the "contilligent5.0.sql" file (i.e double click it to open in mysql front and run the queries)
6)copy the "contelligent" folder to tomcat's webapps folder
7)run the tomat
8)type the following url in browser "http://localhost:8080/contelligent/"