/*StudentLoginServlet.java*/
package studentportal;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import javax.naming.*;
import java.util.*;

public class SubjectMasterServlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{PrintWriter out=res.getWriter();
		try
		{
			String sname=req.getParameter("sname");
			String sdes=req.getParameter("sdes");
			String sid=req.getParameter("sid");
			String cid=req.getParameter("cid");
			String action=req.getParameter("action");
			res.setContentType("text/html");
			
			if (action.equals("Insert"))
			{					
				java.sql.Connection con=MySQLDriver.getConnection();
				java.sql.Statement st=con.createStatement();
				String sss="insert into subject_master(  subject_name, subject_description, semister_id,course_id) values('"+sname+"','"+sdes+"','"+sid+"',"+cid+")";
				System.out.println(sss);
				int c=st.executeUpdate(sss);
				System.out.println("IIIIIIIIIIIIIIIII"+c);	
				if (c==1)
				{
				
					RequestDispatcher rd=req.getRequestDispatcher("/SubjectInsertSuc.html");
					rd.include(req,res);
			      }//if
			     else			
			     {
					RequestDispatcher rd=req.getRequestDispatcher("/AdminSubjectMasterEntry.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Invalid Operaion<br>* Try Once Again</font></p>");
					return;
				  }
			}
			 else			
			     {
					RequestDispatcher rd=req.getRequestDispatcher("/AdminSubjectMasterEntry.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Invalid Operation<br>* Try Once Again</font></p>");
					return;
				  }

			
		}
		catch (Exception e)
		{e.printStackTrace();
			RequestDispatcher rd=req.getRequestDispatcher("/AdminSubjectMasterEntry.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Invalid Operation<br>* Try Once Again</font></p>");
					return;
				
		}
	}
}