package studentportal;
import studentportalBeans.StudentRegHome;
import studentportalBeans.StudentRegRemote;
import studentportalBeans.Student;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import javax.naming.*;
import java.util.*;
public class  StudentRegServlet extends HttpServlet
{
		boolean flag=false;
		public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
		{
			System.out.println("In StudentRegServlet Servlet");

			String sid=req.getParameter("sid");
			String sname=req.getParameter("sname");
			String sadd=req.getParameter("sadd");
			String sdob=req.getParameter("sdob");
			String sphone=req.getParameter("sphone");
			String semail=req.getParameter("semail");
			String scourse=req.getParameter("cid");
			String sdoa=req.getParameter("sdoa");
			String slname=req.getParameter("slogin");
			String slstatus="N";
			String action=req.getParameter("action");
			System.out.println("sid"+sid);
			System.out.println("sdoa"+sdoa);
			System.out.println("action"+action);
			System.out.println("cid"+scourse);
			PrintWriter out=res.getWriter();
	
			try
			{
				InitialContext ic=new InitialContext();
				Object o=ic.lookup("studentportalBeans.StudentRegHome");
				StudentRegHome srh=(StudentRegHome)o;
				StudentRegRemote srr=srh.create();
				if(srr==null)
				{
						RequestDispatcher rd=req.getRequestDispatcher("/StudentRegForm.jsp");
						rd.include(req,res);
						out.println("<p><font color=\"#FF0000\">* Your Details are Not Accepted <br>* Try Once Again</font></p>");
						return;
				}
				else
				{
							Student stu=null;
							if(action.equals("Submit"))
							{
									 flag=srr.insertStudentRec(sid,sname,sadd,sdob,Integer.parseInt(sphone),semail,sdoa,slname,slstatus,scourse);
									 if(flag)
									{
										RequestDispatcher rd=req.getRequestDispatcher("/Sucess.jsp?ope=Insert");
										rd.include(req,res);
										return;
									}
									else
									{
										System.out.println("Inddd");
										RequestDispatcher rd=req.getRequestDispatcher("/StudentRegForm.jsp");
										rd.include(req,res);
										out.println("<p><font color=\"#FF0000\">* Your Details are Not Accepted <br>* Try Once Again</font></p>");
										return;
										}
							}
							if(action.equals("Update"))
							{	
									flag=srr.updateStudentRec(sid,sname,sadd,sdob,Integer.parseInt(sphone),semail,sdoa,slname);
									if(flag)
									{
										RequestDispatcher rd=req.getRequestDispatcher("/Sucess.jsp?ope=Update");
										rd.include(req,res);
										return;
									}
									else
									{
										System.out.println("Inddd");
										RequestDispatcher rd=req.getRequestDispatcher("/StudentUpdateForm.jsp");
										rd.include(req,res);
										out.println("<p><font color=\"#FF0000\">* Your Details are Not Accepted <br>* Try Once Again</font></p>");
										return;
										}
							}
							if(action.equals("Delete"))
							{	
									flag=srr.removeStudentRec(sid);
									if(flag)
									{
										RequestDispatcher rd=req.getRequestDispatcher("/Sucess.jsp?ope=Delete");
										rd.include(req,res);
										return;
									}
									else
									{
										System.out.println("Inddd");
										RequestDispatcher rd=req.getRequestDispatcher("/NewStudentRegStatus.jsp");
										rd.include(req,res);
										out.println("<p><font color=\"#FF0000\">* Your Details are Not Accepted <br>* Try Once Again</font></p>");
										return;
										}
							}
							/*
							if(action.equals("GetHistory"))
							{
									stu=srr.searchByEmail(semail);
									HttpSession hs=req.getSession();
									System.out.println("In History");
									System.out.println("stu is :"+stu);
									hs.setAttribute("Student",stu);
									RequestDispatcher rd=req.getRequestDispatcher("/StudentSearchByEmail1.jsp");
									System.out.println("After rd");
									rd.forward(req,res);
//									return;
							}*/

				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
				RequestDispatcher rd=req.getRequestDispatcher("/StudentRegForm.jsp");
				rd.include(req,res);
				out.println("<p><font color=\"#FF0000\">* Your Details are Not Accepted <br>* Try Once Again</font></p>");
				return;
			}
		}
}
