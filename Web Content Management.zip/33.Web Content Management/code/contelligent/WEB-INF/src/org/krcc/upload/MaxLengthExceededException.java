// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 11/22/2007 7:40:26 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   MaxLengthExceededException.java

package org.krcc.upload;

import java.io.IOException;

public class MaxLengthExceededException extends IOException
{

    public MaxLengthExceededException()
    {
        message = "The maximum length has been exceeded for this request";
    }

    public MaxLengthExceededException(long maxLength)
    {
        message = "The maximum length of " + maxLength + " bytes has been " + "exceeded";
    }

    public String getMessage()
    {
        return message;
    }

    protected String message;
}