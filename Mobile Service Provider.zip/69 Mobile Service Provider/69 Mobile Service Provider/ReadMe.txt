1)install java,install tomcat
2)install oracle
   2.1)go to sqlplus
         by typing 'sqlplus' in the dos prompt
   2.2)type the following commands
	-->connect system/manager
	-->create user mobile identified by mobile 
-->grant all privileges to mobile 
	--->grant dba to mobile 
3)now connect to mobile user and create tables using the queries provided in file Mobile_oracle_DB.txt
3.1)
create a dsn with name 'mobile'
using the following steps

Go to controlpanel>Performance And Maint..>Administrative Tools>DataSource[odbc]>from UserDSN >Add>Select Oracle Driver>Finish>Enter data Source Name as "mobile" and username as "mobile" then click ok....


4)now copy the 'Webroot' folder 
 to  C:\Program Files\Apache Software Foundation\Tomcat 5.0\webapps\     directory

5)start tomcat
6)provide the following url in the browser

http://localhost:8080/webroot/



