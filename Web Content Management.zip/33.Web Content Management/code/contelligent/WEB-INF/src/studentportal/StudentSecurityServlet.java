/*StudentLoginServlet.java*/
package studentportal;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import javax.naming.*;
import java.util.*;

public class StudentSecurityServlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{
		try
		{
			HttpSession hs=req.getSession();
			String sid=(String)hs.getAttribute("StudentId");
			//String sid=req.getParameter("sid");
			String ln=req.getParameter("LN");		
			String old=req.getParameter("Old");			
			String new1=req.getParameter("New1");
			String action=req.getParameter("action");
			System.out.println(sid+" "+ln+""+old+""+new1);

			res.setContentType("text/html");
			PrintWriter out=res.getWriter();
			if (action.equals("Submit"))
			{					
				java.sql.Connection con=MySQLDriver.getConnection();
				java.sql.Statement st=con.createStatement();
				String sss="update student_login set login_name='"+ln+"',pw_old='"+old+"',pw_new='"+new1+"' where student_id='"+sid+"'";
				System.out.println(sss);
				int c=st.executeUpdate(sss);
				sss="update student_master set student_login_name='"+ln+"' where student_id='"+sid+"'";
				if(c>0)
					st.executeUpdate(sss);
				System.out.println("IIIIIIIIIIIIIIIII"+c);	
				if (c==1)
				{
				
					//HttpSession hs=req.getSession();
					//System.out.println("SRRRRR"+rs.getString(1));
					//hs.setAttribute("StudentId",rs.getString(1));
					//String str=(String)hs.getAttribute("StudentId");
					//System.out.println(str);
					//hs.setAttribute("StudentName",rs.getString(2));
					RequestDispatcher rd=req.getRequestDispatcher("/CertificationHome.html");
					rd.include(req,res);
			      }//if
			     else			
			     {
					RequestDispatcher rd=req.getRequestDispatcher("/StudentHome.html");
					rd.include(req,res);
					//out.println("<p><font color=\"#FF0000\">* Invalid User ID or Password<br>* User ID, Password is incorrect</font></p>");
					return;
				  }
			}
			 else			
			     {
					RequestDispatcher rd=req.getRequestDispatcher("/StudentHome.html");
					rd.include(req,res);
					//out.println("<p><font color=\"#FF0000\">* Invalid User ID or Password<br>* User ID, Password is incorrect</font></p>");
					return;
				  }

			
		}
		catch (Exception e)
		{e.printStackTrace();
			
				PrintWriter out=res.getWriter();
				RequestDispatcher rd=req.getRequestDispatcher("/StudentLogin.html");
				rd.include(req,res);
				out.println(" Invalid Button(Apply");
				return;
		}
	}
}