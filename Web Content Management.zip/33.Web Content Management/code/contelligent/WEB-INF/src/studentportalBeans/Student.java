// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 1/28/2008 10:09:51 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Student.java

package studentportalBeans;

import java.io.Serializable;
import java.sql.Date;

public class Student
    implements Serializable
{

    public Student(String s, String s1, String s2, Date date, int i, String s3, Date date1, 
            String s4, String s5)
    {
        sid = s;
        sname = s1;
        sadd = s2;
        sdob = date;
        sphone = i;
        semail = s3;
        sdoa = date1;
        slname = s4;
        slstatus = s5;
    }

    public String sid;
    public String sname;
    public String sadd;
    public String semail;
    public String slname;
    public String slstatus;
    public Date sdob;
    public Date sdoa;
    public int sphone;
}