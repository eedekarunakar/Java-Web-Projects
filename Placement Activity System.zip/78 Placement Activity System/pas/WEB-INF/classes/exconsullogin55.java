import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.io.*;
public class exconsullogin55 extends HttpServlet
 {    Connection con;
      Statement stmt;
      ResultSet rs;
  public void service(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException
    {
      resp.setContentType("text/html");
      PrintWriter out=resp.getWriter();
HttpSession ses=req.getSession(true);
        try{

               new sun.jdbc.odbc.JdbcOdbcDriver();
               con=DriverManager.getConnection("jdbc:odbc:pas","pas","pas");
     System.out.println("this is exconsul login after connection");          
               stmt=con.createStatement();
               String user=req.getParameter("user").trim();
               String pass=req.getParameter("password").trim();
            System.out.println(user);
			            System.out.println(pass);
                 rs=stmt.executeQuery("SELECT CONID,PASS FROM consultant WHERE CONID='"+user+"' and PASS='"+pass+"'");
    

     if(rs.next())
                  {
		 
					System.out.println("befor if"+user);
           	    String uid=req.getParameter("user");
	  				ses.putValue("uid1",uid);      
					resp.sendRedirect("./exconlogsuceee.htm");
           
				 }
                else{					System.out.println("faile"+user);
                     resp.sendRedirect("./exconlogfaill.htm");
                    }
                
             }catch(Exception e){}
      }//service
 }//class
                
            
               
