package studentportal;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class  StudentSearchByEmail extends HttpServlet
{
		public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
		{
			System.out.println("In StudentSearchByEmail Servlet");
			RequestDispatcher rd=req.getRequestDispatcher("./StudentSearchByEmail1.jsp");
			rd.forward(req,res);
		}
}
