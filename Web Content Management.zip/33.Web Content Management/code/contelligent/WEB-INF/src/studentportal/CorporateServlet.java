package studentportal;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class CorporateServlet extends HttpServlet
{
	ServletConfig sc;
	public void init(ServletConfig sc)throws ServletException
	{
		super.init(sc);
		this.sc=sc;
	}
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		String cname=req.getParameter("cname");
		String cdesc=req.getParameter("cdesc");
		String cweb=req.getParameter("cweb");
		String cadd=req.getParameter("cadd");
		String action=req.getParameter("action");

		PrintWriter out=res.getWriter();

		try{
		Connection con=MySQLDriver.getConnection();
		con.setAutoCommit(false);
		Statement st=con.createStatement();
		if(action.equals("Submit"))
		{
			String qry="insert into corporate_master(corporate_name, corporate_desc, corporate_website, corporate_add) values('"+cname+"','"+cdesc+"','"+cweb+"','"+cadd+"')";
			System.out.println(qry);
			int i=st.executeUpdate(qry);
			if(i==1)
			{
				String qry1="insert into corporate_login( cuser, PW_OLD, PW_NEW) values('"+cname+"','"+cname+"','"+cname+"')";
				int j=st.executeUpdate(qry1);
				if(j==1)
				{
				   con.commit();
				   RequestDispatcher rd=req.getRequestDispatcher("/CorporateInsertSuc.jsp");
					rd.forward(req,res);
				}
				else 
				{
					con.rollback();
					RequestDispatcher rd=req.getRequestDispatcher("/NewCorprateHome.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Insertion Operation Faild<br>* Try Once Again</font></p>");
					return;
				}
				
			}
			else
			{
					RequestDispatcher rd=req.getRequestDispatcher("/NewCorprateHome.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Insertion Operation Faild<br>* Try Once Again</font></p>");
					return;
			}
		}
		}//try
		catch(Exception e)
		{
			e.printStackTrace();
			RequestDispatcher rd=req.getRequestDispatcher("/NewCorprateHome.jsp");
			rd.include(req,res);
			out.println("<p><font color=\"#FF0000\">*Operation Faild<br>* Try Once Again</font></p>");
			return;
		}
	}
	public void destroy()
	{
	}
}
