// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 11/22/2007 7:40:25 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   DiskMultipartRequestHandler.java

package org.krcc.upload;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;

// Referenced classes of package org.apache.struts.upload:
//            MultipartIterator, MultipartRequestWrapper, DiskFile, MultipartRequestHandler, 
//            MultipartElement

public class DiskMultipartRequestHandler
    implements MultipartRequestHandler
{

    public DiskMultipartRequestHandler()
    {
    }
	public String getParameter(String name) {
		String value =null;
		textElements=getTextElements();
		if(textElements!=null){
            String mValue[] = (String[])textElements.get(name);
            if(mValue != null && mValue.length > 0)
                value = mValue[0];
        }
        return value;
	}
    public void handleRequest(HttpServletRequest request)
        throws ServletException
    {
        retrieveTempDir();
																	//servlet.getBufferSize() replaced
		MultipartIterator iterator = new MultipartIterator(request, getBufferSize(), getMaxSizeFromServlet(), tempDir);
        textElements = new Hashtable();
        fileElements = new Hashtable();
        allElements = new Hashtable();
        MultipartElement multipartelement;
        try
        {
            while((multipartelement = iterator.getNextElement()) != null) 
                if(!multipartelement.isFile())
                {
                    if(request instanceof MultipartRequestWrapper)
                        ((MultipartRequestWrapper)request).setParameter(multipartelement.getName(), multipartelement.getValue());
                    String textValues[] = (String[])textElements.get(multipartelement.getName());
                    if(textValues != null)
                    {
                        String textValues2[] = new String[textValues.length + 1];
                        System.arraycopy(textValues, 0, textValues2, 0, textValues.length);
                        textValues2[textValues.length] = multipartelement.getValue();
                        textValues = textValues2;
                    } else
                    {
                        textValues = new String[1];
                        textValues[0] = multipartelement.getValue();
                    }
					textElements.put(multipartelement.getName(), textValues);
                    allElements.put(multipartelement.getName(), textValues);
                } else
                {
                    File tempFile = multipartelement.getFile();
                    if(tempFile.exists())
                    {
                        DiskFile theFile = new DiskFile(tempFile.getAbsolutePath());
                        theFile.setContentType(multipartelement.getContentType());
                        theFile.setFileName(multipartelement.getFileName());
                        theFile.setFileSize((int)tempFile.length());
						theFile.setStoredFileName(multipartelement.getStoredFileName());
						theFile.setStoredFilePath(multipartelement.getStoredFilePath());
						theFile.setGreaterThan(multipartelement.isGreaterThan());
						theFile.setZero(multipartelement.isZero());
                        fileElements.put(multipartelement.getName(), theFile);
                        allElements.put(multipartelement.getName(), theFile);
                    }
                }
        }
        catch(UnsupportedEncodingException unsupportedencodingexception)
        {
            throw new ServletException("Encoding \"ISO-8859-1\" not supported");
        }
    }
//code written by srikanth
	public void handleRequest(HttpServletRequest request,boolean skipRead)
        throws ServletException
    {
        retrieveTempDir();
																	//servlet.getBufferSize() replaced
		MultipartIterator iterator = new MultipartIterator(request, getBufferSize(), getMaxSizeFromServlet(), tempDir);
        textElements = new Hashtable();
        fileElements = new Hashtable();
        allElements = new Hashtable();
        MultipartElement multipartelement;
        try
        {
            while((multipartelement = iterator.getNextElement(skipRead)) != null) 
                if(!multipartelement.isFile())
                {
                    if(request instanceof MultipartRequestWrapper)
                        ((MultipartRequestWrapper)request).setParameter(multipartelement.getName(), multipartelement.getValue());
					if(multipartelement.getName().equalsIgnoreCase(FORM_NAME))
						FORM_NAME=multipartelement.getValue();
					if(multipartelement.getName().equalsIgnoreCase(COMMAND))
						COMMAND=multipartelement.getValue();
					if(multipartelement.getName().equalsIgnoreCase(ACTION))
						ACTION=multipartelement.getValue();
                    String textValues[] = (String[])textElements.get(multipartelement.getName());
                    if(textValues != null)
                    {
                        String textValues2[] = new String[textValues.length + 1];
                        System.arraycopy(textValues, 0, textValues2, 0, textValues.length);
                        textValues2[textValues.length] = multipartelement.getValue();
                        textValues = textValues2;
                    } else
                    { 
                        textValues = new String[1];
                        textValues[0] = multipartelement.getValue();
                    }
					textElements.put(multipartelement.getName(), textValues);
                    allElements.put(multipartelement.getName(), textValues);
                } else
                {
                    File tempFile = multipartelement.getFile();
                    if(tempFile!=null && tempFile.exists())
                    {
                        DiskFile theFile = new DiskFile(tempFile.getAbsolutePath());
                        theFile.setContentType(multipartelement.getContentType());
                        theFile.setFileName(multipartelement.getFileName());
                        theFile.setFileSize((int)tempFile.length());
						theFile.setStoredFileName(multipartelement.getStoredFileName());
						theFile.setStoredFilePath(multipartelement.getStoredFilePath());
						theFile.setGreaterThan(multipartelement.isGreaterThan());
						theFile.setZero(multipartelement.isZero());
                        fileElements.put(multipartelement.getName(), theFile);
                        allElements.put(multipartelement.getName(), theFile);
                    }
                }
				setFileConfirm(iterator.isFile());
				setFileGreaterThan(iterator.isGreaterThan());
				setFileZero(iterator.isZero());
        }
        catch(UnsupportedEncodingException unsupportedencodingexception)
        {
            throw new ServletException("Encoding \"ISO-8859-1\" not supported");
        }
    }

    public Hashtable getAllElements()
    {
        return allElements;
    }

    public Hashtable getTextElements()
    {
        return textElements;
    }

    public Hashtable getFileElements()
    {
        return fileElements;
    }

    public void rollback()
    {
        DiskFile theFile;
        for(Enumeration names = fileElements.keys(); names.hasMoreElements(); theFile.destroy())
        {
            String name = (String)names.nextElement();
            theFile = (DiskFile)fileElements.get(name);
        }

    }

    public void finish()
    {
        rollback();
    }

    protected long getMaxSizeFromServlet()
        throws ServletException
    {
        String stringSize = getMaxFileSize();//servlet.getMaxFileSize() replaced
        long size = -1L;
        int multiplier = 1;
        if(stringSize.endsWith("K"))
        {
            multiplier = 1024;
            stringSize = stringSize.substring(0, stringSize.length() - 1);
        }
        if(stringSize.endsWith("M"))
        {
            multiplier = 0x100000;
            stringSize = stringSize.substring(0, stringSize.length() - 1);
        } else
        if(stringSize.endsWith("G"))
        {
            multiplier = 0x40000000;
            stringSize = stringSize.substring(0, stringSize.length() - 1);
        }
        try
        {
            size = Long.parseLong(stringSize);
        }
        catch(NumberFormatException numberformatexception)
        {
            throw new ServletException("Invalid format for maximum file size: \"" + getMaxFileSize() + "\"");//servlet.getMaxFileSize() replaced
        }
        return size * (long)multiplier;
    }

    protected void retrieveTempDir()
    {
        tempDir = path;
        if(tempDir == null)
        {
                tempDir = System.getProperty("java.io.tmpdir");
        }
    }
//Written By Srikanth
    protected String getMaxFileSize() {
	  return maxFileSize;
	}
//Written By Srikanth
    protected int getBufferSize() {
	  return bufferSize;
	}
	public void setFileGreaterThan(boolean isGreaterThan) {
		this.isGreaterThan=isGreaterThan;
	}
	public boolean getFileGreaterThan() {
		return isGreaterThan;
	}
	public void setFileZero(boolean isZero) {
		this.isZero=isZero;
	}
	public boolean getFileZero() {
		return isZero;
	}
	public void setFileConfirm(boolean isFile) {
		this.isFile=isFile;
	}
	public boolean getFileConfirm() {
		return isFile; 
	}
	public void setFormName(String FORM_NAME) {
		this.FORM_NAME=FORM_NAME;
	}
	public String getFormName() {
		return FORM_NAME;
	}
	public void setCommand(String COMMAND) {
		this.COMMAND=COMMAND;
	}
	public String getCommand() {
		return COMMAND;
	}
	public void setAction(String ACTION) {
		this.ACTION=ACTION;
	}
	public String getAction() {
		return ACTION; 
	}
    protected Hashtable fileElements;
    protected Hashtable textElements;
    protected Hashtable allElements;
    protected String tempDir;
	public static String maxFileSize=null; //Ex: 1000K or 1000M or 1000G
	public static int bufferSize=0; //Ex: 4096
	public static String path=null; //Ex: e:/temp
	protected boolean skipRequest=false; //Ex: true don't read the request if > file size
    protected boolean isFile=false;
	protected boolean isGreaterThan=false;
	protected boolean isZero=false; 
	protected String FORM_NAME = "FORMNAME";
    protected String COMMAND   = "COMMAND";
    protected String ACTION = "ACTION";
}