// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 11/22/2007 7:40:23 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   MultipartValueStream.java

package org.krcc.upload;

import java.io.IOException;
import java.io.InputStream;
import javax.servlet.ServletException;

class MultipartValueStream extends InputStream
{

    public MultipartValueStream(InputStream in, String boundary)
        throws IOException
    {
        boundaryReached = false;
        finalBoundaryReached = false;
        this.in = in;
        boundaryBytes = ("\r\n" + boundary).getBytes("iso-8859-1");
        matchedBoundaryBytes = 0;
        readAheadBytes = new byte[boundaryBytes.length];
        if(in.read(readAheadBytes, 0, readAheadBytes.length) != readAheadBytes.length)
            throw new IOException("end of stream before boundary found!");
        for(int i = 0; i < readAheadBytes.length; i++)
            if(readAheadBytes[i] == boundaryBytes[matchedBoundaryBytes])
            {
                matchedBoundaryBytes++;
            } else
            {
                matchedBoundaryBytes = 0;
                if(readAheadBytes[i] == boundaryBytes[0])
                    matchedBoundaryBytes = 1;
            }

        readAheadBufferStartI = 0;
        readAheadBufferEndI = readAheadBytes.length - 1;
    }

    public int read()
        throws IOException
    {
        if(boundaryReached)
            return -1;
        if(matchedBoundaryBytes == boundaryBytes.length)
        {
            boundaryReached = true;
            byte buf[] = new byte[2];
            if(in.read(buf) != 2)
                throw new IOException("end of stream before boundary found!");
            String readStr = new String(buf, "iso-8859-1");
            if(readStr.equals("--"))
            {
                if(in.read(buf) != 2)
                    throw new IOException("invalid end of final boundary found!");
                readStr = new String(buf, "iso-8859-1");
                if(!readStr.equals("\r\n"))
                    throw new IOException("invalid end of final boundary found!");
                finalBoundaryReached = true;
            } else
            if(readStr.equals("\r\n"))
                finalBoundaryReached = false;
            else
                throw new IOException("invalid end of boundary found!");
            return -1;
        }
        int returnByte = (char)readAheadBytes[readAheadBufferStartI];
        readAheadBufferStartI++;
        if(readAheadBufferStartI == readAheadBytes.length)
            readAheadBufferStartI = 0;
        int underlyingRead = in.read();
        if(underlyingRead == -1)
            throw new IOException("end of stream before boundary found!");
        readAheadBufferEndI++;
        if(readAheadBufferEndI == readAheadBytes.length)
            readAheadBufferEndI = 0;
        readAheadBytes[readAheadBufferEndI] = (byte)underlyingRead;
        if(readAheadBytes[readAheadBufferEndI] == boundaryBytes[matchedBoundaryBytes])
        {
            matchedBoundaryBytes++;
        } else
        {
            matchedBoundaryBytes = 0;
            if(readAheadBytes[readAheadBufferEndI] == boundaryBytes[0])
                matchedBoundaryBytes = 1;
        }
        return returnByte;
    }

    public boolean encounteredFinalBoundary()
        throws ServletException
    {
        if(!boundaryReached)
            throw new ServletException("have not reached boundary yet!");
        else
            return finalBoundaryReached;
    }

    public static final String HEADER_ENCODING = "iso-8859-1";
    private InputStream in;
    private byte boundaryBytes[];
    private int matchedBoundaryBytes;
    private byte readAheadBytes[];
    private int readAheadBufferStartI;
    private int readAheadBufferEndI;
    private boolean boundaryReached;
    private boolean finalBoundaryReached;
}