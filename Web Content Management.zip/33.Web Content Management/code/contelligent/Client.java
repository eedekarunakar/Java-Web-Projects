import studentportalBeans.StudentRegHome;
import studentportalBeans.StudentRegRemote;
import java.io.*;
import javax.naming.*;
import java.util.*;
public class Client
{
			public static void main(String args[])throws Exception
			{
						
						InitialContext ic=new InitialContext();
						Object o=ic.lookup("studentportalBeans.StudentRegHome");
						StudentRegHome srh=(StudentRegHome)o;
						StudentRegRemote srr=srh.create();
						System.out.println(srr.getMessage());
			}
};