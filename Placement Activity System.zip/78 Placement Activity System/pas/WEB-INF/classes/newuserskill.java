
import javax.servlet.*;
import java.text.*;
import javax.servlet.http.*;
import java.util.*;
import java.io.*;
import java.sql.*;
public class newuserskill extends HttpServlet
{
 PrintWriter out;
 Connection con;
 Statement stmt;
 ResultSet rs;
 int agg;
 public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
 {
  res.setContentType("text/html");
  out=res.getWriter();
 
  try
  {
	   String uid=req.getParameter("uid");
	  String totexp=req.getParameter("totexp");
   String skill1=req.getParameter("skill1");
   String skill2=req.getParameter("skill2");
   String skill3=req.getParameter("skill3");
      String skill4=req.getParameter("skill4");
String skill5=req.getParameter("skill5");
      String skill6=req.getParameter("skill6");

   String othskill=req.getParameter("othskill");
   String descskill=req.getParameter("descskill");
   
   
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("jdbc:odbc:pas","pas","pas");
   Statement stmt=con.createStatement();
       PreparedStatement ps=con.prepareStatement("INSERT INTO SKILLS(userid,totexp,skill1,skill2,skill3,skill4,skill5,skill6,otherskills,descskills) VALUES(?,?,?,?,?,?,?,?,?,?)");

	System.out.println("after inserting into the database");
ps.setString(1,uid);
ps.setString(2,skill1);
ps.setString(3,skill2);
ps.setString(4,skill3);
ps.setString(5,skill4);
ps.setString(6,skill5);
ps.setString(7,skill6);

    ps.setString(8,othskill);
    ps.setString(9,descskill);
    ps.setString(10,totexp);
    
   System.out.println(uid);
    int i=ps.executeUpdate();

	
    res.sendRedirect("./sucesseskills1.jsp");
	ps.close();
   
   stmt.close();
   con.close(); 
  }
  catch(Exception e)
  {
   e.printStackTrace();
  }
 
  out.close();
 }
}

 	
   







