
import javax.servlet.*;
import java.text.*;
import javax.servlet.http.*;
import java.util.*;
import java.io.*;
import java.sql.*;
public class newuserqul extends HttpServlet
{
 PrintWriter out;
 Connection con;
 Statement stmt;
 ResultSet rs;
 int agg;
 public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
 {
  res.setContentType("text/html");
  out=res.getWriter();
 
  try
  {
	  String hqul=req.getParameter("hqul");
   String pg=req.getParameter("pg");
   String grad=req.getParameter("grad");
   String inter=req.getParameter("inter");
      String ssc=req.getParameter("ssc");
String interctno=req.getParameter("interctno");
      String sscctno=req.getParameter("sscctno");

   String other1=req.getParameter("other1");
   String othercert=req.getParameter("othercert");
   String uid=req.getParameter("uid");

String pun=req.getParameter("pun");
   String gun=req.getParameter("gun");
   String gper=req.getParameter("gper");
      String pgper=req.getParameter("pgper");
   

   
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("jdbc:odbc:pas","pas","pas");
	if(con!=null)
	 System.out.println("Successful");
   Statement stmt=con.createStatement();
   PreparedStatement ps=con.prepareStatement("INSERT INTO EDUCATION(userid,qul,postg,pgunv,pgper,gradu,gradunv,gradper,inter,intercertno,ssc,ssccertno,otherqul,othercert) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
	System.out.println("after html form reading values");
	ps.setString(1,uid);
    ps.setString(2,hqul);
    ps.setString(3,pg);
    ps.setString(4,pun);
    ps.setString(5,pgper);
	
    ps.setString(6,grad);
    ps.setString(7,gun);
    ps.setString(8,gper);
	 ps.setString(9,inter);
    ps.setString(10,interctno);
	ps.setString(11,ssc);
    ps.setString(12,sscctno);
    ps.setString(13,other1);
    ps.setString(14,othercert);

   System.out.println(uid);
    int i=ps.executeUpdate();
System.out.println("Valu of i "+i);
System.out.println("after inserting into the table education");
	
    res.sendRedirect("./sucesseducationaldetails1.jsp");
	ps.close();
   
   stmt.close();
   con.close(); 
  }
  catch(Exception e)
  {
   e.printStackTrace();
  }
 
  out.close();
 }
}

 	
   







