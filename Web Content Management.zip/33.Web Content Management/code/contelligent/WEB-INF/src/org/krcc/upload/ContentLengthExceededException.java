// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 11/22/2007 7:40:23 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ContentLengthExceededException.java

package org.krcc.upload;

import java.io.IOException;

public class ContentLengthExceededException extends IOException
{

    public ContentLengthExceededException()
    {
        message = "The Content-Length has been exceeded for this request";
    }

    public ContentLengthExceededException(long contentLength)
    {
        message = "The Content-Length of " + contentLength + " bytes has been " + "exceeded";
    }

    public String getMessage()
    {
        return message;
    }

    protected String message;
}