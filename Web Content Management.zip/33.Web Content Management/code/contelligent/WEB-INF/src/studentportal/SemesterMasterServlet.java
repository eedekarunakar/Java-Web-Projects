/*StudentLoginServlet.java*/
package studentportal;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import javax.naming.*;
import java.util.*;

public class SemesterMasterServlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{PrintWriter out=res.getWriter();
		try
		{
			String name=req.getParameter("name");
			String desc=req.getParameter("desc");
			String ssdate=req.getParameter("ssdate");
			String sedate=req.getParameter("sedate");
			String year=req.getParameter("year");
			String action=req.getParameter("action");
			res.setContentType("text/html");
			
			if (action.equals("Insert"))
			{					
				java.sql.Connection con=MySQLDriver.getConnection();
				java.sql.Statement st=con.createStatement();
				String sss="insert into semister_master(semister_name, semister_desc, sem_start_date, sem_end_date, academic_year) values('"+name+"','"+desc+"','"+ssdate+"','"+sedate+"','"+year+"')";
				System.out.println(sss);
				int c=st.executeUpdate(sss);
				System.out.println("IIIIIIIIIIIIIIIII"+c);	
				if (c==1)
				{
				
					RequestDispatcher rd=req.getRequestDispatcher("/SemisterInsertSuc.html");
					rd.include(req,res);
			      }//if
			     else			
			     {
					RequestDispatcher rd=req.getRequestDispatcher("/AdminSemesterMasterEntry.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Invalid Operaion<br>* Try Once Again</font></p>");
					return;
				  }
			}
			 else			
			     {
					RequestDispatcher rd=req.getRequestDispatcher("/AdminSemesterMasterEntry.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Invalid Operation<br>* Try Once Again</font></p>");
					return;
				  }

			
		}
		catch (Exception e)
		{e.printStackTrace();
			RequestDispatcher rd=req.getRequestDispatcher("/AdminSemesterMasterEntry.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Invalid Operation<br>* Try Once Again</font></p>");
					return;
				
		}
	}
}