// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 11/22/2007 7:40:25 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   BufferedMultipartInputStream.java

package org.krcc.upload;

import java.io.*;

// Referenced classes of package org.apache.struts.upload:
//            MaxLengthExceededException, ContentLengthExceededException

public class BufferedMultipartInputStream extends InputStream
{

    public BufferedMultipartInputStream(InputStream inputStream, int bufferSize, long contentLength, long maxSize)
        throws IOException
    {
        bufferOffset = 0;
        this.bufferSize = 8192;
        bufferLength = 0;
        totalLength = 0;
        this.maxSize = -1L;
        contentLengthMet = false;
        maxLengthMet = false;
        this.inputStream = inputStream;
        this.bufferSize = bufferSize;
        this.contentLength = contentLength;
        this.maxSize = maxSize;
        if(maxSize < contentLength)
        {
            throw new MaxLengthExceededException(maxSize);
        } else
        {
            buffer = new byte[bufferSize];
            fill();
            return;
        }
    }

    public int available()
    {
        return bufferLength - bufferOffset;
    }

    public void close()
        throws IOException
    {
        inputStream.close();
    }

    public void mark(int position)
    {
        inputStream.mark(position);
    }

    public boolean markSupported()
    {
        return inputStream.markSupported();
    }

    public boolean maxLengthMet()
    {
        return maxLengthMet;
    }

    public boolean contentLengthMet()
    {
        return contentLengthMet;
    }

    public int read()
        throws IOException
    {
        if(maxLengthMet)
            throw new MaxLengthExceededException(maxSize);
        if(contentLengthMet)
            throw new ContentLengthExceededException(contentLength);
        if(buffer == null)
            return -1;
        if(bufferOffset < bufferLength)
        {
            return (char)buffer[bufferOffset++];
        } else
        {
            fill();
            return read();
        }
    }

    public int read(byte b[])
        throws IOException
    {
        return read(b, 0, b.length);
    }

    public int read(byte b[], int offset, int length)
        throws IOException
    {
        int read = read();
        if(read == -1)
            return -1;
        int count;
        for(count = 1; read != -1 && count < length;)
        {
            b[offset] = (byte)read;
            read = read();
            count++;
            offset++;
        }

        return count;
    }

    public int readLine(byte b[], int offset, int length)
        throws IOException
    {
        int count = 0;
        int read = read();
        if(read == -1)
            return -1;
        for(; read != -1 && count < length; read = read())
        {
            if(read == 10)
                break;
            b[offset] = (byte)read;
            count++;
            offset++;
        }

        return count;
    }

    public byte[] readLine()
        throws IOException
    {
        int read = read();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        if(-1 == read)
            return null;
        for(; read != -1 && read != 10; read = read())
            baos.write(read);

        return baos.toByteArray();
    }

    public void reset()
        throws IOException
    {
        inputStream.reset();
    }

    protected void fill()
        throws IOException
    {
        if(bufferOffset > -1 && bufferLength > -1)
        {
            int length = Math.min(bufferSize, ((int)contentLength + 1) - totalLength);
            if(length == 0)
                contentLengthMet = true;
            if(maxSize > -1L && length > 0)
            {
                length = Math.min(length, (int)maxSize - totalLength);
                if(length == 0)
                    maxLengthMet = true;
            }
            int bytesRead = -1;
            if(length > 0)
                bytesRead = inputStream.read(buffer, 0, length);
            if(bytesRead == -1)
            {
                buffer = null;
                bufferOffset = -1;
                bufferLength = -1;
            } else
            {
                bufferLength = bytesRead;
                totalLength += bytesRead;
                bufferOffset = 0;
            }
        }
    }

    protected InputStream inputStream;
    protected byte buffer[];
    protected int bufferOffset;
    protected int bufferSize;
    protected int bufferLength;
    protected int totalLength;
    protected long contentLength;
    protected long maxSize;
    protected boolean contentLengthMet;
    protected boolean maxLengthMet;
}