import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class Testlogin extends HttpServlet 
{
	Connection con;
    Statement stmt;
 	ResultSet rs;
		   
	public void service(HttpServletRequest hreq,HttpServletResponse hresp) throws ServletException,IOException 
	{
        //    hresp.setContentType("text/html");
			String name=hreq.getParameter("uname");
			String password=hreq.getParameter("password");
	try{
		    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con=DriverManager.getConnection("jdbc:odbc:pas","pas","pas");
			stmt=con.createStatement();
			rs=stmt.executeQuery("select userid,pass from jobseekers where userid='"+name+"'and pass='"+password+"'");
			if(rs.next())
		   {
			  hresp.sendRedirect("./Choose Test.html");
		   }
	   else{
		     hresp.sendRedirect("./testlogin.html");
		   }
	    }
	   catch(Exception e)
		{
		e.printStackTrace();
		}
	}
}


	    