package studentportal;
import studentportalBeans.StudentRegHome;
import studentportalBeans.StudentRegRemote;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import javax.naming.*;
public class  Reg extends HttpServlet
{
		public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
		{
						try
						{
						InitialContext ic=new InitialContext();
						Object o=ic.lookup("studentportalBeans.StudentRegHome");
						StudentRegHome srh=(StudentRegHome)o;
						StudentRegRemote srr=srh.create();
						System.out.println(srr.getMessage());
						}catch(Exception e)
			{
							e.printStackTrace();

			}
		}
}
