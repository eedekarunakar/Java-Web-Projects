// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 1/28/2008 10:09:56 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   StudentRegRemote.java

package studentportalBeans;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;

// Referenced classes of package studentportalBeans:
//            Student

public interface StudentRegRemote
    extends EJBObject
{

    public abstract boolean insertStudentRec(String s, String s1, String s2, String s3, int i, String s4, String s5, 
            String s6, String s7, String s8)
        throws RemoteException;

    public abstract boolean updateStudentRec(String s, String s1, String s2, String s3, int i, String s4, String s5, 
            String s6)
        throws RemoteException;

    public abstract boolean removeStudentRec(String s)
        throws RemoteException;

    public abstract Student searchByEmail(String s)
        throws RemoteException;

    public abstract String getMessage()
        throws RemoteException;
}