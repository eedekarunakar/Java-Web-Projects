package studentportal;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class  Faculties_Available_Main extends HttpServlet
{
		public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
		{
			System.out.println("In Faculties_Available_Main Servlet");
			RequestDispatcher rd=req.getRequestDispatcher("./Faculties_Available_Main.jsp");
			rd.forward(req,res);
		}
}
