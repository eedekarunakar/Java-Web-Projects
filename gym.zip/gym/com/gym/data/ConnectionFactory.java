package com.gym.data;
import java.sql.Connection;
import java.sql.DriverManager;
	public class ConnectionFactory {

		public static Connection getCon() throws Exception{
			
			Connection con=null;
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","gym","gym");
			return con;
		}
		
		
}
