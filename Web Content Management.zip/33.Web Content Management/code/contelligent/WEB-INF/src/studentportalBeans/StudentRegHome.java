// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 1/28/2008 10:09:53 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   StudentRegHome.java

package studentportalBeans;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

// Referenced classes of package studentportalBeans:
//            StudentRegRemote

public interface StudentRegHome
    extends EJBHome
{

    public abstract StudentRegRemote create()
        throws CreateException, RemoteException;
}