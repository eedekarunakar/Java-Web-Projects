import javax.servlet.*;
import java.text.*;
import javax.servlet.http.*;
import java.util.*;
import java.io.*;
import java.sql.*;
public class newuserexp extends HttpServlet
{
 PrintWriter out;
 Connection con;
 Statement stmt;
 ResultSet rs;
 int agg;
 public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
 {
  res.setContentType("text/html");
  out=res.getWriter();
 
  try
  {
	   String uid=req.getParameter("uid");
	  String expfield=req.getParameter("expfield");
   String onsit=req.getParameter("onsit");
   String pfrom=req.getParameter("pfrom");
   String prsal=req.getParameter("prsal");
      String totexp=req.getParameter("totexp");
String pwcomp=req.getParameter("pwcomp");
      String urle=req.getParameter("urle");

   String expsal=req.getParameter("expsal");
String pto=req.getParameter("pto");
   
   
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("jdbc:odbc:pas","pas","pas");
   Statement stmt=con.createStatement();
       PreparedStatement ps=con.prepareStatement("INSERT INTO EXPERIENCE VALUES(?,?,?,?,?,?,?,?,?,?)");

	System.out.println("after inserting into the database");
 System.out.println(uid);
   System.out.println("the total exp"+totexp);
   System.out.println(expfield);
   System.out.println(pwcomp);

ps.setString(1,uid);
ps.setString(2,totexp);
ps.setString(3,expfield);
ps.setString(4,pwcomp);
ps.setString(5,onsit);
ps.setString(6,pfrom);
ps.setString(7,pto);

    ps.setString(8,prsal);
    ps.setString(9,expsal);
    ps.setString(10,urle);
    
   System.out.println(uid);
   System.out.println(totexp);
   System.out.println(expfield);
   System.out.println(pwcomp);

	int i=ps.executeUpdate();

	
    res.sendRedirect("./sucessexp.jsp");
	ps.close();
   
   stmt.close();
   con.close(); 
  }
  catch(Exception e)
  {
   e.printStackTrace();
  }
 
  out.close();
 }
}

 	
   







