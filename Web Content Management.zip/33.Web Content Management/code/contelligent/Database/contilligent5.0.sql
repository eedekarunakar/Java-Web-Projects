-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.18-nt


CREATE DATABASE IF NOT EXISTS test;
USE test;

--
-- Definition of table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `usid` varchar(20) default NULL,
  `pwd` varchar(20) default NULL
) ;

--
-- Dumping data for table `admin`
--

/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`usid`,`pwd`) VALUES 
 ('admin','admin');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;


--
-- Definition of table `admin_corporate`
--

DROP TABLE IF EXISTS `admin_corporate`;
CREATE TABLE `admin_corporate` (
  `CORPORATE_ID` varchar(15) default NULL,
  `NOTIFICATION_ID` varchar(15) default NULL,
  `NOTI_DATE` date default NULL,
  `NOTI_LDATE` date default NULL,
  `NOTIFICATION` text
) ;

--
-- Dumping data for table `admin_corporate`
--

/*!40000 ALTER TABLE `admin_corporate` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_corporate` ENABLE KEYS */;


--
-- Definition of table `admission_master`
--

DROP TABLE IF EXISTS `admission_master`;
CREATE TABLE `admission_master` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `type` varchar(100) NOT NULL,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admission_master`
--

/*!40000 ALTER TABLE `admission_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `admission_master` ENABLE KEYS */;


--
-- Definition of table `book_borrow`
--

DROP TABLE IF EXISTS `book_borrow`;
CREATE TABLE `book_borrow` (
  `borrow_id` int(10) unsigned NOT NULL auto_increment,
  `book_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `request_date` date NOT NULL,
  `from_date` date default NULL,
  `to_date` date default NULL,
  `book_name` varchar(100) default NULL,
  `author` varchar(100) default NULL,
  `edition` varchar(100) default NULL,
  `status` varchar(45) NOT NULL default 'A',
  PRIMARY KEY  (`borrow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_borrow`
--

/*!40000 ALTER TABLE `book_borrow` DISABLE KEYS */;
/*!40000 ALTER TABLE `book_borrow` ENABLE KEYS */;


--
-- Definition of table `book_master`
--

DROP TABLE IF EXISTS `book_master`;
CREATE TABLE `book_master` (
  `book_id` int(10) unsigned NOT NULL auto_increment,
  `book_name` varchar(100) default NULL,
  `author` varchar(100) default NULL,
  `edition` varchar(100) default NULL,
  `book_status` varchar(45) default 'N',
  `isbn` varchar(100) default NULL,
  `purchased_date` date default NULL,
  PRIMARY KEY  (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_master`
--

/*!40000 ALTER TABLE `book_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `book_master` ENABLE KEYS */;


--
-- Definition of table `branch_master`
--

DROP TABLE IF EXISTS `branch_master`;
CREATE TABLE `branch_master` (
  `branch_id` int(10) unsigned NOT NULL auto_increment,
  `branch_name` varchar(100) default NULL,
  `branch_desc` varchar(100) default NULL,
  PRIMARY KEY  (`branch_id`)
) ;

--
-- Dumping data for table `branch_master`
--

/*!40000 ALTER TABLE `branch_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `branch_master` ENABLE KEYS */;


--
-- Definition of table `catalog`
--

DROP TABLE IF EXISTS `catalog`;
CREATE TABLE `catalog` (
  `book_id` varchar(15) NOT NULL default '',
  `book_name` varchar(20) default NULL,
  `book_author` varchar(20) default NULL,
  `book_edition` varchar(10) default NULL,
  PRIMARY KEY  (`book_id`)
) ;

--
-- Dumping data for table `catalog`
--

/*!40000 ALTER TABLE `catalog` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalog` ENABLE KEYS */;


--
-- Definition of table `corporate_login`
--

DROP TABLE IF EXISTS `corporate_login`;
CREATE TABLE `corporate_login` (
  `cid` int(10) unsigned NOT NULL auto_increment,
  `cuser` varchar(10) default NULL,
  `PW_OLD` varchar(10) default NULL,
  `PW_NEW` varchar(10) default NULL,
  PRIMARY KEY  (`cid`)
) ;

--
-- Dumping data for table `corporate_login`
--

/*!40000 ALTER TABLE `corporate_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `corporate_login` ENABLE KEYS */;


--
-- Definition of table `corporate_master`
--

DROP TABLE IF EXISTS `corporate_master`;
CREATE TABLE `corporate_master` (
  `corporate_id` int(10) unsigned NOT NULL auto_increment,
  `corporate_name` varchar(20) default NULL,
  `corporate_desc` varchar(30) default NULL,
  `corporate_website` varchar(30) default NULL,
  `corporate_add` varchar(40) default NULL,
  PRIMARY KEY  (`corporate_id`)
) ;

--
-- Dumping data for table `corporate_master`
--

/*!40000 ALTER TABLE `corporate_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `corporate_master` ENABLE KEYS */;


--
-- Definition of table `course_master`
--

DROP TABLE IF EXISTS `course_master`;
CREATE TABLE `course_master` (
  `course_id` int(10) unsigned NOT NULL auto_increment,
  `course_name` varchar(100) default NULL,
  `course_short_name` varchar(100) default NULL,
  `course_description` varchar(100) default NULL,
  `course_fee` decimal(10,0) default NULL,
  `branch_id` int(10) unsigned NOT NULL,
  `academic_year` date default NULL,
  PRIMARY KEY  (`course_id`)
) ;

--
-- Dumping data for table `course_master`
--

/*!40000 ALTER TABLE `course_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_master` ENABLE KEYS */;


--
-- Definition of table `designation_master`
--

DROP TABLE IF EXISTS `designation_master`;
CREATE TABLE `designation_master` (
  `designation_id` int(10) unsigned NOT NULL auto_increment,
  `desigantion_name` varchar(100) default NULL,
  `desigantion_description` varchar(100) default NULL,
  PRIMARY KEY  (`designation_id`)
) ;

--
-- Dumping data for table `designation_master`
--

/*!40000 ALTER TABLE `designation_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `designation_master` ENABLE KEYS */;


--
-- Definition of table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `FIRST_NAME` varchar(100) default NULL,
  `LAST_NAME` varchar(100) default NULL,
  `DESIGNATION` varchar(45) default NULL,
  `WORK_LOCATION` varchar(45) default NULL,
  `WORK_PHONE` varchar(45) default NULL,
  `EMAIL` varchar(100) default NULL,
  `LOGIN_NAME` varchar(45) NOT NULL,
  `PASSWORD` varchar(45) NOT NULL,
  `WORK_HOURS` varchar(45) default NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;


--
-- Definition of table `faculty_assign_master`
--

DROP TABLE IF EXISTS `faculty_assign_master`;
CREATE TABLE `faculty_assign_master` (
  `assign_id` int(10) unsigned NOT NULL auto_increment,
  `faculty_id` int(10) unsigned NOT NULL,
  `branch_id` int(10) unsigned NOT NULL,
  `course_id` int(10) unsigned NOT NULL,
  `semister_id` int(10) unsigned NOT NULL,
  `subject_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`assign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty_assign_master`
--

/*!40000 ALTER TABLE `faculty_assign_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `faculty_assign_master` ENABLE KEYS */;


--
-- Definition of table `faculty_assignment_master`
--

DROP TABLE IF EXISTS `faculty_assignment_master`;
CREATE TABLE `faculty_assignment_master` (
  `assignment_id` int(10) unsigned NOT NULL auto_increment,
  `assign_id` int(10) unsigned NOT NULL,
  `assignment_name` varchar(100) default NULL,
  `assignment_desc` varchar(100) default NULL,
  `attach_name` varchar(100) default NULL,
  `physical_file` varchar(100) default NULL,
  `date` date default NULL,
  `logical_file` varchar(100) default NULL,
  PRIMARY KEY  (`assignment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty_assignment_master`
--

/*!40000 ALTER TABLE `faculty_assignment_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `faculty_assignment_master` ENABLE KEYS */;


--
-- Definition of table `faculty_login`
--

DROP TABLE IF EXISTS `faculty_login`;
CREATE TABLE `faculty_login` (
  `faculty_id` varchar(15) default NULL,
  `Login_name` varchar(20) default NULL,
  `pw_old` varchar(30) default NULL,
  `pw_new` varchar(30) default NULL,
  `pw_changed_date` date default NULL
) ;

--
-- Dumping data for table `faculty_login`
--

/*!40000 ALTER TABLE `faculty_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `faculty_login` ENABLE KEYS */;


--
-- Definition of table `faculty_master`
--

DROP TABLE IF EXISTS `faculty_master`;
CREATE TABLE `faculty_master` (
  `faculty_id` int(10) unsigned NOT NULL auto_increment,
  `faculty_name` varchar(100) default NULL,
  `faculty_address` varchar(100) default NULL,
  `faculty_dob` date default NULL,
  `faculty_phone` int(11) default NULL,
  `faculty_email` varchar(100) default NULL,
  `faculty_join_date` date default NULL,
  `faculty_dept_id` varchar(100) default NULL,
  `faculty_designation_id` varchar(100) default NULL,
  `faculty_login_name` varchar(100) default NULL,
  `faculty_lstatus` varchar(100) default NULL,
  PRIMARY KEY  (`faculty_id`)
) ;

--
-- Dumping data for table `faculty_master`
--

/*!40000 ALTER TABLE `faculty_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `faculty_master` ENABLE KEYS */;


--
-- Definition of table `notes_master`
--

DROP TABLE IF EXISTS `notes_master`;
CREATE TABLE `notes_master` (
  `notes_id` int(10) unsigned NOT NULL auto_increment,
  `assign_id` int(10) unsigned NOT NULL,
  `notes_name` varchar(100) NOT NULL,
  `notes_description` varchar(100) NOT NULL,
  `attach_name` varchar(100) NOT NULL,
  `physical_file` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `logical_file` varchar(200) NOT NULL,
  PRIMARY KEY  (`notes_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notes_master`
--

/*!40000 ALTER TABLE `notes_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes_master` ENABLE KEYS */;


--
-- Definition of table `notification_master`
--

DROP TABLE IF EXISTS `notification_master`;
CREATE TABLE `notification_master` (
  `notification_id` varchar(15) NOT NULL default '',
  `NOTI_DATE` date default NULL,
  `NOTI_LDATE` date default NULL,
  `NOTIFICATION` varchar(100) default NULL,
  `indended_for` varchar(20) default NULL,
  `status` char(3) default NULL,
  PRIMARY KEY  (`notification_id`)
) ;

--
-- Dumping data for table `notification_master`
--

/*!40000 ALTER TABLE `notification_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_master` ENABLE KEYS */;


--
-- Definition of table `semister_master`
--

DROP TABLE IF EXISTS `semister_master`;
CREATE TABLE `semister_master` (
  `semister_id` int(10) unsigned NOT NULL auto_increment,
  `semister_name` varchar(100) default NULL,
  `semister_desc` varchar(100) default NULL,
  `sem_start_date` date default NULL,
  `sem_end_date` date default NULL,
  `academic_year` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`semister_id`)
) ;

--
-- Dumping data for table `semister_master`
--

/*!40000 ALTER TABLE `semister_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `semister_master` ENABLE KEYS */;


--
-- Definition of table `student_assignment_master`
--

DROP TABLE IF EXISTS `student_assignment_master`;
CREATE TABLE `student_assignment_master` (
  `sassignment_id` int(10) unsigned NOT NULL auto_increment,
  `assignment_id` int(10) unsigned NOT NULL,
  `assign_id` int(10) unsigned NOT NULL,
  `student_id` int(10) unsigned NOT NULL,
  `date` date NOT NULL,
  `physical_file` varchar(100) NOT NULL,
  PRIMARY KEY  (`sassignment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_assignment_master`
--

/*!40000 ALTER TABLE `student_assignment_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_assignment_master` ENABLE KEYS */;


--
-- Definition of table `student_certificates`
--

DROP TABLE IF EXISTS `student_certificates`;
CREATE TABLE `student_certificates` (
  `student_id` varchar(15) default NULL,
  `certificates` varchar(40) default NULL,
  `apply_date` date default NULL,
  `apply_status` char(3) default NULL
) ;

--
-- Dumping data for table `student_certificates`
--

/*!40000 ALTER TABLE `student_certificates` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_certificates` ENABLE KEYS */;


--
-- Definition of table `student_login`
--

DROP TABLE IF EXISTS `student_login`;
CREATE TABLE `student_login` (
  `student_id` varchar(15) default NULL,
  `Login_name` varchar(20) default NULL,
  `pw_old` varchar(30) default NULL,
  `pw_new` varchar(30) default NULL,
  `pw_changed_date` date default NULL
) ;

--
-- Dumping data for table `student_login`
--

/*!40000 ALTER TABLE `student_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_login` ENABLE KEYS */;


--
-- Definition of table `student_marks`
--

DROP TABLE IF EXISTS `student_marks`;
CREATE TABLE `student_marks` (
  `sid` varchar(15) default NULL,
  `student_name` varchar(20) default NULL,
  `sub1` int(11) default NULL,
  `sub2` int(11) default NULL,
  `sub3` int(11) default NULL,
  `sub4` int(11) default NULL,
  `sub5` int(11) default NULL
) ;

--
-- Dumping data for table `student_marks`
--

/*!40000 ALTER TABLE `student_marks` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_marks` ENABLE KEYS */;


--
-- Definition of table `student_master`
--

DROP TABLE IF EXISTS `student_master`;
CREATE TABLE `student_master` (
  `student_id` int(10) unsigned NOT NULL auto_increment,
  `student_name` varchar(45) default NULL,
  `student_address` varchar(40) default NULL,
  `student_dob` date default NULL,
  `student_phone` int(15) default NULL,
  `student_email` varchar(30) default NULL,
  `student_admt_date` date default NULL,
  `student_login_name` varchar(30) default NULL,
  `student_login_status` varchar(30) default NULL,
  `course_id` varchar(15) default NULL,
  PRIMARY KEY  (`student_id`)
) ;

--
-- Dumping data for table `student_master`
--

/*!40000 ALTER TABLE `student_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_master` ENABLE KEYS */;


--
-- Definition of table `subject_master`
--

DROP TABLE IF EXISTS `subject_master`;
CREATE TABLE `subject_master` (
  `subject_id` int(10) unsigned NOT NULL auto_increment,
  `subject_name` varchar(100) default NULL,
  `subject_description` varchar(100) default NULL,
  `semister_id` int(10) unsigned NOT NULL,
  `course_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`subject_id`)
) ;


