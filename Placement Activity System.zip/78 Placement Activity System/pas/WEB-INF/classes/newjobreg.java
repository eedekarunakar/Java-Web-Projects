
import javax.servlet.*;
import java.text.*;
import javax.servlet.http.*;
import java.util.*;
import java.io.*;
import java.sql.*;
public class newjobreg extends HttpServlet
{
 PrintWriter out;
 Connection con;
 Statement stmt;
 ResultSet rs;
 
 int agg;
 public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
 {
  res.setContentType("text/html");
  out=res.getWriter();
 
 HttpSession ses=req.getSession(true);
  try
  {
	  String jobtit=req.getParameter("jobtit");
	   String jobcode=req.getParameter("jobcode");
   String skill1=req.getParameter("skill1");
   String skill2=req.getParameter("skill2");
      String skill3=req.getParameter("skill3");
   String skill4=req.getParameter("skill4");
   String skill5=req.getParameter("skill5");
   String skill6=req.getParameter("skill6");
//***************************************
String exp=req.getParameter("exp");
   String odate=req.getParameter("odate");
   String closdate=req.getParameter("closdate");
   String cid=req.getParameter("cid");

	
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("jdbc:odbc:pas","pas","pas");
   Statement stmt=con.createStatement();
       PreparedStatement ps=con.prepareStatement("INSERT INTO joborder(clientid,jobtitle,jobcode,skill1,skill2,skill3,skill4,skill5,skill6,noyexp,reldate,closdate) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");

	System.out.println("after html form reading values");
	ps.setString(1,cid);
	ps.setString(2,jobtit);
    ps.setString(3,jobcode);
    ps.setString(4,skill1);
    ps.setString(5,skill2);
    ps.setString(6,skill3);
	ps.setString(7,skill4);
    ps.setString(8,skill5);
    ps.setString(9,skill6);
	ps.setString(10,exp);
  	ps.setString(11,odate);
    ps.setString(12,closdate);
    
       
    int i=ps.executeUpdate();
System.out.println("after inserting into the joborder table");
	
    res.sendRedirect("./sucessnewjobdet.htm");
	ps.close();
   
   stmt.close();
   con.close(); 
  }
  catch(Exception e)
  {
   e.printStackTrace();
  }
 
  out.close();
 }
}

 	
   







