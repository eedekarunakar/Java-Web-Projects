/*StudentLoginServlet.java*/
package studentportal;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import javax.naming.*;
import java.util.*;

public class AdminLoginServlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{
		try
		{
			String uid=req.getParameter("username");
			String pass=req.getParameter("password");

			res.setContentType("text/html");
			PrintWriter out=res.getWriter();
			if (uid==null||pass==null)
			{
				RequestDispatcher rd=req.getRequestDispatcher("/AdminLogin.html");
				rd.include(req,res);
				out.println("<p><font color=\"#FF0000\">* Invalid User ID or Password<br>* User ID or Password is null</font></p>");
				return;
			}
			else if ("".equals(uid)||"".equals(pass))
			{
				RequestDispatcher rd=req.getRequestDispatcher("/AdminLogin.html");
				rd.include(req,res);
				out.println("<p><font color=\"#FF0000\">* Invalid User ID or Password<br>* User ID or Password is empty</font></p>");
				return;
			}
			java.sql.Connection con=MySQLDriver.getConnection();
                        System.out.println(con);
			java.sql.Statement st=con.createStatement();
			String sss="select * from admin where usid='"+uid+"' and pwd='"+pass+"'";
			System.out.println(sss);
			java.sql.ResultSet rs=st.executeQuery(sss);
			if (rs.next())
			{
				

				RequestDispatcher rd=req.getRequestDispatcher("/AdminHome.html");
				rd.include(req,res);

			}//if
			else			
			{
				RequestDispatcher rd=req.getRequestDispatcher("/AdminLogin.html");
				rd.include(req,res);
				out.println("<p><font color=\"#FF0000\">* Invalid User ID or Password<br>* User ID, Password is incorrect</font></p>");
				return;
			}
			

			
		}
		catch (Exception e)
		{
                                
                e.printStackTrace();
				PrintWriter out=res.getWriter();
				RequestDispatcher rd=req.getRequestDispatcher("/AdminLogin.html");
				rd.include(req,res);
				out.println("<p><font color=\"#FF0000\">* Invalid User ID or Password<br>* User ID, Password is incorrect</font></p>");
				return;
		}
	}
}