// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 11/22/2007 7:40:26 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   MultipartElement.java

package org.krcc.upload;

import java.io.File;

public class MultipartElement
{

    /**
     * @deprecated Method MultipartElement is deprecated
     */

    public MultipartElement(String name, String fileName, String contentType, byte data[])
    {
        isFile = false;
        this.name = name;
        this.fileName = fileName;
        this.contentType = contentType;
        this.data = data;
        if(fileName != null)
            isFile = true;
    }

    public MultipartElement(String name, String fileName, String contentType, File file)
    {
        isFile = false;
        this.name = name;
        this.fileName = fileName;
        this.contentType = contentType;
        this.file = file;
		this.storedFileName=file.getName();
		this.storedFilePath=file.getAbsolutePath();
        isFile = true;
    }
    public MultipartElement(String name, String fileName, String contentType, File file,boolean isGreaterThan,boolean isZero)
    {
        isFile = false;
        this.name = name;
        this.fileName = fileName;
        this.contentType = contentType;
        this.file = file;
		if(file!=null) {
	 	  this.storedFileName=file.getName();
		  this.storedFilePath=file.getAbsolutePath();
		}
        isFile = true;
		this.isZero=isZero;
		this.isGreaterThan=isGreaterThan;
    }
 
    public MultipartElement(String name, String value)
    {
        isFile = false;
        this.name = name;
        this.value = value;
        isFile = false;
    }

    public String getContentType()
    {
        return contentType;
    }

    /**
     * @deprecated Method getData is deprecated
     */

    public byte[] getData()
    {
        return data;
    }

    public File getFile()
    {
        return file;
    }

    public String getName()
    {
        return name;
    }

    public String getFileName()
    {
        return fileName;
    }

    public String getValue()
    {
        return value;
    }

    public void setFile(File file)
    {
        this.file = file;
    }

    public void setFileName(String fileName)
    {
        this.fileName = fileName;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public void setContentType(String contentType)
    {
        this.contentType = contentType;
    }

    public boolean isFile()
    {
        return file != null;
    }

    public void setValue(String value)
    {
        this.value = value;
    }
	
	public void setStoredFileName(String storedFileName) {
		this.storedFileName=storedFileName;
	}
	public String getStoredFileName() {
		return storedFileName;
	}
	public void setStoredFilePath(String storedFilePath) {
		this.storedFilePath=storedFilePath;
	}
	public String getStoredFilePath() {
		return storedFilePath;
	}
	//Srikanth written code
	public boolean isGreaterThan() {
		return isGreaterThan;  
	}
	public boolean isZero() {
		return isZero;
	}
	/**
     * @deprecated Method setData is deprecated
     */

    public void setData(byte data[])
    {
        this.data = data;
    }

    protected String contentType;
    /**
     * @deprecated Field data is deprecated
     */
    protected byte data[];
    protected File file;
    protected String name;
    protected String fileName;
    protected String storedFileName;
    protected String storedFilePath;
    protected String value;
    protected boolean isFile=false;
	protected boolean isGreaterThan=false;
	protected boolean isZero=false; 
}