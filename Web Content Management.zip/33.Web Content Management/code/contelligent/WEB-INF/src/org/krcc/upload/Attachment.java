package org.krcc.upload;
public class Attachment {
  private boolean isGreaterThan=false;
  private boolean isZero=false; 
  private String size=null;
  private String realFileName=null;
  private String physicalFileName=null;
  private String physicalFilePath=null;
  private String contentType=null;
  private String description=null;
	public void setGreaterThan(boolean isGreaterThan) {
		this.isGreaterThan=isGreaterThan;
	}
	public boolean getGreaterThan() {
		return isGreaterThan;
	}
	public void setZero(boolean isZero) {
		this.isZero=isZero;
	}
	public boolean getZero() {
		return isZero; 
	}
  public void setSize(String size) {
    this.size=size;
  }
  public String getSize() {
    return size;
  }
  public void setRealFileName(String realFileName)  {
    this.realFileName=realFileName;
  }
  public String getRealFileName() {
    return realFileName;
  }
  public void setPhysicalFilePath(String physicalFilePath) {
    this.physicalFilePath=physicalFilePath;
  }
  public String getPhysicalFilePath() {
    return physicalFilePath;
  }
  public void setPhysicalFileName(String physicalFileName) {
    this.physicalFileName=physicalFileName;
  }
  public String getPhysicalFileName() {
    return physicalFileName;
  }
  public void setContentType(String contentType) {
    this.contentType=contentType;
  }
  public String getContentType() {
    return contentType;
  }
  public void setDescription(String description) {
    this.description=description;
  }
  public String getDescription() {
    return description;
  }
}