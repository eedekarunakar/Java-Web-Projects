//This function is to check the date format


function checkValidation(strFromDateObj,strToDateObj) {
	var strFromDate = strFromDateObj.value
	var strToDate = strToDateObj.value
	var returnFlag = true,strEmptyFlag = false
	
	if(strFromDate == "" && strToDate == "") {
		strEmptyFlag = true
	}
	
	
	if(strEmptyFlag == false) {
		if(strFromDate != "" && strToDate == "") {
			alert("Please Enter To Date")
			strToDateObj.focus()
			returnFlag = false
		}else if(strFromDate == "" && strToDate != "") {
			alert("Please Enter From Date")
			strFromDateObj.focus()
			returnFlag = false
		}
	}
	
	if(returnFlag == true) {
		if(returnFlag == true && strEmptyFlag == false) {
			if (strFromDate > strToDate){
				alert ("From Date Should Be Less Than To Date");
				strFromDateObj.focus()
				returnFlag = false
			}
		}
	}
	return returnFlag
}

function funClear(objControl) {
	objControl.value = ""
}


function removeKeys(e) {
  var key=window.event?e.keyCode:e.which;
  if(key==13)
    startClick();
	e.cancelBubble=true;
	e.returnValue=false;
	return false;
}