/*StudentLoginServlet.java*/
package studentportal;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import javax.naming.*;
import java.util.*;

public class DeptMasterServlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{PrintWriter out=res.getWriter();
		try
		{
			String did=req.getParameter("did");
			String dname=req.getParameter("dname");
			String ddes=req.getParameter("ddes");
			String action=req.getParameter("action");
			res.setContentType("text/html");
			
			if (action.equals("Insert"))
			{					
				java.sql.Connection con=MySQLDriver.getConnection();
				java.sql.Statement st=con.createStatement();
				String sss="insert into department_master( department_name, department_description) values('"+dname+"','"+ddes+"')";
				System.out.println(sss);
				int c=st.executeUpdate(sss);
				System.out.println("IIIIIIIIIIIIIIIII"+c);	
				if (c==1)
				{
				
					RequestDispatcher rd=req.getRequestDispatcher("/DeptInsertSuc.html");
					rd.include(req,res);
			      }//if
			     else			
			     {
					RequestDispatcher rd=req.getRequestDispatcher("/AdminDeptMasterEntry.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Invalid Operaion<br>* Try Once Again</font></p>");
					return;
				  }
			}
			 else			
			     {
					RequestDispatcher rd=req.getRequestDispatcher("/AdminDeptMasterEntry.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Invalid Operation<br>* Try Once Again</font></p>");
					return;
				  }

			
		}
		catch (Exception e)
		{e.printStackTrace();
			RequestDispatcher rd=req.getRequestDispatcher("/AdminDeptMasterEntry.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Invalid Operation<br>* Try Once Again</font></p>");
					return;
				
		}
	}
}