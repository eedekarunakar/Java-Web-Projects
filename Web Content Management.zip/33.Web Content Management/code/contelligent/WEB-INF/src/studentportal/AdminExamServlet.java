package studentportal;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class AdminExamServlet extends HttpServlet
{
	ServletConfig sc;
	public void init(ServletConfig sc)throws ServletException
	{
		super.init(sc);
		this.sc=sc;
	}
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		String eid=req.getParameter("eid");
		String ename=req.getParameter("ename");
		String etype=req.getParameter("etype");
		String semid=req.getParameter("semid");
		String cid=req.getParameter("cid");
        String subid=req.getParameter("subid");
        String exstart=req.getParameter("exstart");
	    String exend=req.getParameter("exend");
	    String exfee=req.getParameter("exfee");
		String action=req.getParameter("action");

		PrintWriter out=res.getWriter();

		try{
		Connection con=MySQLDriver.getConnection();
		Statement st=con.createStatement();
		if(action.equals("Insert"))
		{
			String qry="insert into examination_master values('"+eid+"','"+ename+"','"+etype+"','"+semid+"','"+cid+"','"+subid+"','"+exstart+"','"+exend+"',"+exfee+")";
			System.out.println(qry);
			int i=st.executeUpdate(qry);
			if(i==1)
			{
				RequestDispatcher rd=req.getRequestDispatcher("/ExamInsertSuc.jsp");
				rd.forward(req,res);
			}
			else
			{
					RequestDispatcher rd=req.getRequestDispatcher("/AdminExamsHome.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Insertion Operation Faild<br>* Try Once Again</font></p>");
					return;
			}
		}
		else if(action.equals("Update"))
		{
				String qry="update examination_master set examination_name='"+ename+"',exam_type='"+etype+"',semister_id='"+semid+"',course_id='"+cid+"',subject_id='"+subid+"',exam_start_date='"+exstart+"',exam_end_date='"+exend+"' where examination_id='"+eid+"'";
				System.out.println(qry);
				int i=st.executeUpdate(qry);
				if(i==1)
				{
					RequestDispatcher rd=req.getRequestDispatcher("/ExamUpdateSuc.jsp");
					rd.forward(req,res);
				}
				else
				{
					RequestDispatcher rd=req.getRequestDispatcher("/AdminExamsHome.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Update Operation Faild<br>* Try Once Again</font></p>");
					return;
				}
		}
		else if(action.equals("Delete"))
		{
			String qry="delete from examination_master where examination_id='"+eid+"'";
			System.out.println(qry);
			int i=st.executeUpdate(qry);
			if(i==1)
			{
						RequestDispatcher rd=req.getRequestDispatcher("/ExamDeleteSuc.jsp");
						rd.forward(req,res);
			}
			else
			{
					RequestDispatcher rd=req.getRequestDispatcher("/AdminExamsHome.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Deletion Operation Faild<br>* Try Once Again</font></p>");
					return;
			}
		}
		else if(action.equals("Search"))
		{
						RequestDispatcher rd=req.getRequestDispatcher("/AdminExamSearch.jsp");
						rd.forward(req,res);
			
		}
		else if(action.equals("List"))
		{
			RequestDispatcher rd=req.getRequestDispatcher("/ExamsList.jsp");
			rd.forward(req,res);
		}
		}//try
		catch(Exception e)
		{
			e.printStackTrace();
			RequestDispatcher rd=req.getRequestDispatcher("/AdminExamsHome.jsp");
			rd.include(req,res);
			out.println("<p><font color=\"#FF0000\">*Operation Faild<br>* Try Once Again</font></p>");
			return;
		}
	}
	public void destroy()
	{
	}
}
