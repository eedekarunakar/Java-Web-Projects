package studentportal;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class  NewStudentRegStatus extends HttpServlet
{
		public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
		{
			System.out.println("In NewStudentRegStatus Servlet");
			RequestDispatcher rd=req.getRequestDispatcher("./NewStudentRegStatus.jsp");
			rd.forward(req,res);
		}
}
