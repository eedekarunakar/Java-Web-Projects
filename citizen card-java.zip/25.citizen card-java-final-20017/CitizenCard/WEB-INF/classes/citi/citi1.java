package citi;
import java.sql.*;
public class citi1
{
 public static Connection getConnection() throws Exception
{
/*Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection con=DriverManager.getConnection("jdbc:odbc:dara","citi","citi");*/

Class.forName("oracle.jdbc.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","citi","citi");
Statement st=con.createStatement();
return con;
}
}