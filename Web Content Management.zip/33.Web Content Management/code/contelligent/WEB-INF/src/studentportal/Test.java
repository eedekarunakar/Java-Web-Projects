package studentportal;
import java.sql.*;
public class  Test
{
	public static void main(String[] args) throws Exception
	{
					Connection con=MySQLDriver.getConnection(); 
					Statement st=con.createStatement();
					
					System.out.println("After Statement");
					

					ResultSet rs=st.executeQuery("select * from catalog");
					System.out.println("After ResultSet");
					while(rs.next())
					{
						System.out.println(rs.getString(1));
					}
	
				
	}
}