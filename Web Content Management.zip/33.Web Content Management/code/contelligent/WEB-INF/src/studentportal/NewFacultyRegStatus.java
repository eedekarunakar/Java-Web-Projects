package studentportal;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class  NewFacultyRegStatus extends HttpServlet
{
		public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
		{
			System.out.println("In NewFacultyRegStatus Servlet");
			RequestDispatcher rd=req.getRequestDispatcher("./NewFacultyRegStatus.jsp");
			rd.forward(req,res);
		}
}
