package studentportal;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class  Catalogs extends HttpServlet
{
		public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
		{
			System.out.println("In Catalogs Servlet");
			RequestDispatcher rd=req.getRequestDispatcher("./Catalogs.jsp");
			rd.forward(req,res);
		}
}
