
import javax.servlet.*;
import java.text.*;
import javax.servlet.http.*;
import java.util.*;
import java.io.*;
import java.sql.*;
public class newuserpersonal extends HttpServlet
{
 PrintWriter out;
 Connection con;
 Statement stmt;
 ResultSet rs;
 
 int agg;
 public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
 {
  res.setContentType("text/html");
  out=res.getWriter();
 
 HttpSession ses=req.getSession(true);
  try
  {
	  String nid=req.getParameter("userid");
	  ses.putValue("nid1",nid);
   String pass=req.getParameter("pass");
   String fname=req.getParameter("fname");
   String mname=req.getParameter("mname");
      String lname=req.getParameter("lname");

   String gend=req.getParameter("gend");
   String pmadd=req.getParameter("pmadd");
   String psadd=req.getParameter("psadd");
//***************************************
String city=req.getParameter("city");
   String state=req.getParameter("state");
   String country=req.getParameter("country");
   //String cphoff=req.getParameter("cphoff");
    //  String offex=req.getParameter("offex");

   String cphres=req.getParameter("cphres");
   String mph=req.getParameter("mph");
   String passno=req.getParameter("passno");
String cobj=req.getParameter("cobj");
String pin=req.getParameter("pin");
   
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("jdbc:odbc:pas","pas","pas");
   Statement stmt=con.createStatement();
       PreparedStatement ps=con.prepareStatement("INSERT INTO JOBSEEKERS(userid,pass,fname,mname,lname,prstadd,partadd,pin,city,state,country,resphno,passportno,carrobj,mobileno,gender) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

	System.out.println("after html form reading values");
	ps.setString(1,nid);
    ps.setString(2,pass);
    ps.setString(3,fname);
    ps.setString(4,mname);
    ps.setString(5,lname);
	
    ps.setString(6,psadd);
    ps.setString(7,pmadd);
    ps.setString(8,pin);
	 ps.setString(9,city);
    ps.setString(10,state);
	ps.setString(11,country);

    //ps.setString(12,cphoff);
    //ps.setString(13,offex);

    ps.setString(12,cphres);
    ps.setString(13,passno);
	ps.setString(14,cobj);
	ps.setString(15,mph);
	ps.setString(16,gend);


   
    int i=ps.executeUpdate();
System.out.println("after inserting into the table");
	out.println(nid);
    res.sendRedirect("./sucesspersonaldetails.jsp");
	ps.close();
   
   stmt.close();
   con.close(); 
  }
  catch(Exception e)
  {
   e.printStackTrace();
  }
 
  out.close();
 }
}

 	
   







