// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 11/22/2007 7:40:22 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   FormFile.java

package org.krcc.upload;

import java.io.*;

public interface FormFile
{

    public abstract String getContentType();

    public abstract void setContentType(String s);

    public abstract int getFileSize();

    public abstract void setFileSize(int i);

    public abstract String getFileName();

    public abstract void setFileName(String s);

    public abstract byte[] getFileData()
        throws FileNotFoundException, IOException;

    public abstract InputStream getInputStream()
        throws FileNotFoundException, IOException;

    public abstract void destroy();
}