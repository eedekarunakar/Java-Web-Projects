/*
 * Created on April 3, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Administrator
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GetBooksBean {
	
	String bookid;
	public void setBookid(String bookid)
	{
		this.bookid=bookid;
	}
	public String getBookid()
	{
		return bookid;
	}

}
