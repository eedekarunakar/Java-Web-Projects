// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 11/22/2007 7:40:26 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   MultipartRequestHandler.java

package org.krcc.upload;

import java.util.Hashtable;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
//import org.apache.struts.action.ActionMapping;
//import org.apache.struts.action.ActionServlet;

public interface MultipartRequestHandler
{

//    public abstract void setServlet(ActionServlet actionservlet);

//    public abstract void setMapping(ActionMapping actionmapping);

//    public abstract ActionServlet getServlet();

  //  public abstract ActionMapping getMapping();

    public abstract void handleRequest(HttpServletRequest httpservletrequest)
        throws ServletException;

    public abstract Hashtable getTextElements();

    public abstract Hashtable getFileElements();

    public abstract Hashtable getAllElements();

    public abstract void rollback();

    public abstract void finish();
}