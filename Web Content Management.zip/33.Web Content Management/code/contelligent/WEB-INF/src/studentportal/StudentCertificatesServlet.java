/*StudentLoginServlet.java*/
package studentportal;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import javax.naming.*;
import java.util.*;

public class StudentCertificatesServlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{
		try
		{
			String sno=req.getParameter("sno");		
			String tc=req.getParameter("TC");			
			String adate=req.getParameter("Adate");
			String status="n";
			String action=req.getParameter("action");
			System.out.println(sno+" "+tc+""+adate+""+action);

			res.setContentType("text/html");
			PrintWriter out=res.getWriter();
			if (action.equals("Apply"))
			{					
				java.sql.Connection con=MySQLDriver.getConnection();
				java.sql.Statement st=con.createStatement();
				String sss="insert into student_certificates values('"+sno+"','"+tc+"','"+adate+"','n')";
				System.out.println(sss);
				int c=st.executeUpdate(sss);

				if (c==1)
				{						
					RequestDispatcher rd=req.getRequestDispatcher("/CertificationHome.html");
					rd.include(req,res);
			      }//if
			     else			
			     {
					RequestDispatcher rd=req.getRequestDispatcher("/StudentHome.html");
					rd.include(req,res);
					//out.println("<p><font color=\"#FF0000\">* Invalid User ID or Password<br>* User ID, Password is incorrect</font></p>");
					return;
				  }
			}
			 else			
			     {
					RequestDispatcher rd=req.getRequestDispatcher("/StudentHome.html");
					rd.include(req,res);
					//out.println("<p><font color=\"#FF0000\">* Invalid User ID or Password<br>* User ID, Password is incorrect</font></p>");
					return;
				  }

			
		}
		catch (Exception e)
		{e.printStackTrace();
			
				PrintWriter out=res.getWriter();
				RequestDispatcher rd=req.getRequestDispatcher("/StudentLogin.html");
				rd.include(req,res);
				out.println(" Invalid Button(Apply");
				return;
		}
	}
}