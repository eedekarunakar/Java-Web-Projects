/*StudentLoginServlet.java*/
package studentportal;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import javax.naming.*;
import java.util.*;

public class CourseMasterServlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{PrintWriter out=res.getWriter();
		try
		{
			String cid=req.getParameter("CNO");
			String cname=req.getParameter("CNAME");
			String cshort=req.getParameter("CSHORTNAME");
			String cdesc=req.getParameter("CDESC");
			String cfee=req.getParameter("CFEE");
			String bid=req.getParameter("bid");
			String year=req.getParameter("YEAR");
			String action=req.getParameter("action");

			res.setContentType("text/html");
			
			if (action.equals("Insert"))
			{					
				java.sql.Connection con=MySQLDriver.getConnection();
				java.sql.Statement st=con.createStatement();
				String sss="insert into course_master(course_name, course_short_name, course_description, course_fee,branch_id,academic_year) values('"+cname+"','"+cshort+"','"+cdesc+"','"+cfee+"',"+bid+",'"+year+"')";
				int c=st.executeUpdate(sss);
				if (c==1)
				{
				
					RequestDispatcher rd=req.getRequestDispatcher("/CourseInsertSuc.html");
					rd.include(req,res);
			      }//if
			     else			
			     {
					RequestDispatcher rd=req.getRequestDispatcher("/AdminCourseMasterEntry.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Invalid Operaion<br>* Try Once Again</font></p>");
					return;
				  }
			}
			 else			
			     {
					RequestDispatcher rd=req.getRequestDispatcher("/AdminCourseMasterEntry.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Invalid Operation<br>* Try Once Again</font></p>");
					return;
				  }

			
		}
		catch (Exception e)
		{e.printStackTrace();
			RequestDispatcher rd=req.getRequestDispatcher("/AdminCourseMasterEntry.jsp");
					rd.include(req,res);
					out.println("<p><font color=\"#FF0000\">* Invalid Operation<br>* Try Once Again</font></p>");
					return;
				
		}
	}
}