// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 11/22/2007 7:40:25 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   DiskFile.java

package org.krcc.upload;

import java.io.*;

// Referenced classes of package org.apache.struts.upload:
//            FormFile

public class DiskFile
    implements FormFile
{

    public DiskFile(String filePath)
    {
        this.filePath = filePath;
    }

    public byte[] getFileData()
        throws FileNotFoundException, IOException
    {
        byte bytes[] = new byte[getFileSize()];
        FileInputStream fis = new FileInputStream(filePath);
        fis.read(bytes);
        fis.close();
        return bytes;
    }

    public byte[] getFileData(int bufferSize)
        throws FileNotFoundException, IOException
    {
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        FileInputStream fis = new FileInputStream(filePath);
        int readLength = 0;
        int totalLength = 0;
        int offset = 0;
        byte bytes[] = new byte[bufferSize];
        while((readLength = fis.read(bytes, offset, bufferSize)) != -1) 
        {
            byteStream.write(bytes, offset, bufferSize);
            totalLength += readLength;
            offset += readLength;
        }
        bytes = byteStream.toByteArray();
        fis.close();
        byteStream.close();
        return bytes;
    }

    public void destroy()
    {
        File tempFile = new File(filePath);
        if(tempFile.exists())
            tempFile.delete();
    }

    public String getFilePath()
    {
        return filePath;
    }

    public void setFileName(String filename)
    {
        fileName = filename;
    }

    public void setContentType(String contentType)
    {
        this.contentType = contentType;
    }

    public void setFileSize(int fileSize)
    {
        this.fileSize = fileSize;
    }

    public String getFileName()
    {
        return fileName;
    }

    public String getContentType()
    {
        return contentType;
    }

    public int getFileSize()
    {
        return fileSize;
    }

    public InputStream getInputStream()
        throws FileNotFoundException, IOException
    {
        return new FileInputStream(filePath);
    }
	public void setStoredFileName(String storedFileName) {
		this.storedFileName=storedFileName;
	}
	public String getStoredFileName() {
		return storedFileName;
	}
	public void setStoredFilePath(String storedFilePath) {
		this.storedFilePath=storedFilePath;
	}
	public String getStoredFilePath() {
		return storedFilePath;
	}
	//Srikanth written code
	public void setGreaterThan(boolean isGreaterThan) {
		this.isGreaterThan=isGreaterThan;
	}
	public boolean getGreaterThan() {
		return isGreaterThan;
	}
	public void setZero(boolean isZero) {
		this.isZero=isZero;
	}
	public boolean getZero() {
		return isZero; 
	}
    protected String filePath;
    protected String contentType;
    protected int fileSize;
    protected String fileName;
    protected String storedFileName; 
    protected String storedFilePath;
	protected boolean isGreaterThan=false;
	protected boolean isZero=false; 
}