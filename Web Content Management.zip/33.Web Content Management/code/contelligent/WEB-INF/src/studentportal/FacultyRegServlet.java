package studentportal;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import javax.naming.*;
import java.util.*;
import java.sql.*;
public class  FacultyRegServlet extends HttpServlet
{
		int flag=0;
		public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
		{
			System.out.println("In StudentRegServlet Servlet");

			String fid=req.getParameter("fid");
			String fname=req.getParameter("fname");
			String fadd=req.getParameter("fadd");
			String fdob=req.getParameter("fdob");
			String fphone=req.getParameter("fphone");
			String femail=req.getParameter("femail");
			String fdoa=req.getParameter("fdoa");
			String fdept=req.getParameter("fdept");
			String fdeg=req.getParameter("fdeg");
			String flname=req.getParameter("flogin");
			String flstatus="N";
			String action=req.getParameter("action");
			System.out.println("sid"+fid);
			System.out.println("sdoa"+fdoa);
			System.out.println("action"+action);
			PrintWriter out=res.getWriter();
			Connection con=null;
			Statement st1=null;
			try
			{
				con=MySQLDriver.getConnection(); 
/*				if(srr==null)
				{
						RequestDispatcher rd=req.getRequestDispatcher("/FacultyRegForm.jsp");
						rd.include(req,res);
						out.println("<p><font color=\"#FF0000\">* Your Details are Not Accepted <br>* Try Once Again</font></p>");
						return;
				}
				else
				{*/
							if(action.equals("Submit"))
							{					st1=con.createStatement();
									 flag= st1.executeUpdate("insert into faculty_master(faculty_name, faculty_address, faculty_dob, faculty_phone, faculty_email, faculty_join_date, faculty_dept_id, faculty_designation_id, faculty_login_name, faculty_lstatus) values('"+fname+"',"+"'"+fadd+"','"+fdob+"','"+fphone+"','"+femail+"','"+fdoa+"','"+fdept+"','"	+fdeg+"','"+flname+"','"+flstatus+"')");
									 st1.close();
									 if(flag>0)
									{
										RequestDispatcher rd=req.getRequestDispatcher("/Sucess.jsp?ope=Insert");
										rd.include(req,res);
										return;
									}
									else
									{
										System.out.println("Inddd");
										RequestDispatcher rd=req.getRequestDispatcher("/FacultyRegForm.jsp");
										rd.include(req,res);
										out.println("<p><font color=\"#FF0000\">* Your Details are Not Accepted <br>* Try Once Again</font></p>");
										return;
										}
							}
							if(action.equals("Update"))
							{	
								
									System.out.println("Doa"+fdoa+"deg"+fdeg);
										st1=con.createStatement();
									 flag= st1.executeUpdate("update faculty_master set faculty_name='"+fname+"', " +"faculty_address='"+fadd+"', faculty_dob='"+fdob+"', faculty_phone='"+fphone+"', faculty_email='"+femail+"'," +" faculty_join_date='"+fdoa+"', faculty_dept_id='"+fdept+"', faculty_designation_id='"	+fdeg+"', faculty_login_name='"+flname+"' where faculty_id="+fid); 
									 st1.close();
									if(flag>0)
									{
										RequestDispatcher rd=req.getRequestDispatcher("/Sucess.jsp?ope=Update");
										rd.include(req,res);
										return;
									}
									else
									{
										System.out.println("Inddd");
										RequestDispatcher rd=req.getRequestDispatcher("/FacultyUpdateForm.jsp");
										rd.include(req,res);
										out.println("<p><font color=\"#FF0000\">* Your Details are Not Accepted <br>* Try Once Again</font></p>");
										return;
										}
							}
							if(action.equals("Delete"))
							{	
								st1=con.createStatement();
								 flag= st1.executeUpdate("delete from faculty_master  where faculty_id="+fid); 
								 st1.close();
								if(flag>0)
									{
										RequestDispatcher rd=req.getRequestDispatcher("/Sucess.jsp?ope=Delete");
										rd.include(req,res);
										return;
									}
									else
									{
										System.out.println("Inddd");
										RequestDispatcher rd=req.getRequestDispatcher("/NewFacultyRegStatus.jsp");
										rd.include(req,res);
										out.println("<p><font color=\"#FF0000\">* Your Details are Not Accepted <br>* Try Once Again</font></p>");
										return;
										}
							}

				//}
			}
			catch(Exception e)
			{
				e.printStackTrace();
				RequestDispatcher rd=req.getRequestDispatcher("/StudentRegForm.jsp");
				rd.include(req,res);
				out.println("<p><font color=\"#FF0000\">* Your Details are Not Accepted <br>* Try Once Again</font></p>");
		try {
				if(con!=null)
					   con.close();
		}catch(Exception e1){System.out.println(e1);}
				return;
			}
			}
}
